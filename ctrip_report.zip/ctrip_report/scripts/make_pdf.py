#!/usr/bin/env python3
"""把质检报告 Markdown 转成精排 PDF。

用法：
    python make_pdf.py <md 文件路径>

输出：同目录同名 .pdf 文件（页眉标题自动从 md 第一个 # 标题提取）

环境依赖：
    pip install markdown weasyprint --break-system-packages
    系统需要 Noto Sans/Serif CJK 字体（Ubuntu: apt-get install fonts-noto-cjk）
"""

import sys
import re
import markdown
from weasyprint import HTML, CSS
from pathlib import Path

# --- 命令行参数 ---
if len(sys.argv) < 2:
    print("用法：python make_pdf.py <md 文件路径>", file=sys.stderr)
    sys.exit(1)

MD_PATH = Path(sys.argv[1])
if not MD_PATH.exists():
    print(f"错误：找不到文件 {MD_PATH}", file=sys.stderr)
    sys.exit(1)

OUT_PATH = MD_PATH.with_suffix(".pdf")

# --- 1. Markdown → HTML ---
md_text = MD_PATH.read_text(encoding="utf-8")

# 从第一个 # 标题提取酒店名作为页眉
_m = re.search(r"^#\s+(.+?)\s*$", md_text, flags=re.MULTILINE)
HOTEL_NAME = _m.group(1).strip() if _m else "酒店质检报告"
# 页眉长度控制（太长会挤到日期）
HEADER_TEXT = f"{HOTEL_NAME} · 携程主页质检报告"

# --- 预处理：修复 markdown 中常见的"粗体行紧接列表/表格"排版问题 ---
# python-markdown 的标准行为：列表/表格前必须有空行，否则会被并入上方段落。
# 这里在"**...** 独占一行"后没有空行就直接跟 `- ` / `1. ` / `|` 的地方自动插入空行。
md_text = re.sub(
    r"(^\*\*[^*\n]+\*\*\s*)\n(?=[-*]\s|\d+\.\s|\|)",
    r"\1\n\n",
    md_text,
    flags=re.MULTILINE,
)

# --- 把报告抬头那行 "**xxx**：yyy **zzz**：aaa" 拆成块级列表，便于排版 ---
def _split_meta_line(m):
    line = m.group(0)
    pairs = re.findall(r"\*\*([^*]+?)\*\*：([^*\n]+?)(?=\s*\*\*|$)", line)
    if len(pairs) < 2:
        return line
    return "\n".join(f"- **{k}**：{v.strip()}" for k, v in pairs)

md_text = re.sub(
    r"^\*\*[^*\n]+\*\*：[^\n]*\*\*[^*\n]+\*\*：[^\n]*$",
    _split_meta_line,
    md_text,
    flags=re.MULTILINE,
)

html_body = markdown.markdown(
    md_text,
    extensions=["tables", "fenced_code", "toc", "sane_lists", "attr_list"],
    output_format="html5",
)

# --- 2. 精排 CSS ---
# 设计取向：
# - 正文 Noto Serif CJK SC（衬线），质感接近专业咨询报告
# - 标题 Noto Sans CJK SC（无衬线），层级对比强
# - 单色 + 适量灰阶，避免花哨
# - 表格斑马纹、清晰边框
# - 引用块用左边粗线强调
# - 中英文混排数字不换行

CSS_STR = r"""
@page {
    size: A4;
    margin: 20mm 18mm 22mm 18mm;

    @top-left {
        content: "__HEADER__";
        font-family: "Noto Sans CJK SC", sans-serif;
        font-size: 9pt;
        color: #888;
        margin-top: 8mm;
    }
    @top-right {
        content: "2026-04-21";
        font-family: "Noto Sans CJK SC", sans-serif;
        font-size: 9pt;
        color: #888;
        margin-top: 8mm;
    }
    @bottom-center {
        content: counter(page) " / " counter(pages);
        font-family: "Noto Sans CJK SC", sans-serif;
        font-size: 9pt;
        color: #888;
        margin-bottom: 8mm;
    }
}

/* 首页无页眉 */
@page :first {
    @top-left { content: ""; }
    @top-right { content: ""; }
}

html {
    font-size: 10.5pt;
}

body {
    font-family: "Noto Serif CJK SC", "Source Han Serif SC", serif;
    line-height: 1.75;
    color: #222;
    text-align: justify;
    word-break: keep-all;
    overflow-wrap: break-word;
}

/* --- 标题 --- */
h1, h2, h3, h4, h5, h6 {
    font-family: "Noto Sans CJK SC", "Source Han Sans SC", sans-serif;
    color: #1a1a1a;
    line-height: 1.4;
    page-break-after: avoid;
}

h1 {
    font-size: 24pt;
    font-weight: 700;
    margin: 0 0 8pt 0;
    padding-bottom: 10pt;
    border-bottom: 2.5pt solid #1a1a1a;
    letter-spacing: 0.5pt;
}

h2 {
    font-size: 16pt;
    font-weight: 700;
    margin: 28pt 0 14pt 0;
    padding: 6pt 0 6pt 10pt;
    border-left: 4pt solid #1a1a1a;
    background: #f4f4f4;
    page-break-before: auto;
}

/* 第一个 h2 不翻页 */
h1 + h2,
h1 + p + h2,
h1 + p + p + h2,
h1 + p + p + p + h2,
h1 + hr + h2,
h1 + p + hr + h2,
h1 + p + p + hr + h2 {
    page-break-before: avoid;
}

h3 {
    font-size: 13pt;
    font-weight: 700;
    margin: 20pt 0 10pt 0;
    color: #2b2b2b;
}

h4 {
    font-size: 11.5pt;
    font-weight: 700;
    margin: 14pt 0 6pt 0;
    color: #3a3a3a;
}

/* --- 段落 --- */
p {
    margin: 0 0 8pt 0;
    text-indent: 0;
}

/* 报告副标题（h1 下方紧跟的 h2，旧格式） */
h1 + h2 {
    font-size: 14pt;
    border-left: none;
    background: none;
    padding: 0;
    margin: 0 0 14pt 0;
    color: #666;
    font-weight: 400;
}

/* --- 元数据块（报告日期等） --- */
h1 ~ p strong:first-child {
    color: #555;
}

/* --- 列表 --- */
ul, ol {
    margin: 6pt 0 10pt 0;
    padding-left: 20pt;
}

li {
    margin: 3pt 0;
    line-height: 1.7;
}

ul ul, ol ol, ul ol, ol ul {
    margin: 3pt 0;
}

/* --- 强调 --- */
strong {
    font-weight: 700;
    color: #000;
}

em {
    font-style: normal;
    color: #555;
}

/* --- 表格 --- */
table {
    width: 100%;
    border-collapse: collapse;
    margin: 12pt 0 16pt 0;
    font-size: 9.5pt;
    page-break-inside: auto;
}

table thead {
    display: table-header-group;
}

table tr {
    page-break-inside: avoid;
}

th {
    background: #2a2a2a;
    color: #fff;
    font-family: "Noto Sans CJK SC", sans-serif;
    font-weight: 700;
    padding: 7pt 9pt;
    text-align: left;
    border: 0.5pt solid #2a2a2a;
    line-height: 1.4;
}

td {
    padding: 6pt 9pt;
    border: 0.5pt solid #ccc;
    line-height: 1.55;
    vertical-align: top;
}

tbody tr:nth-child(even) td {
    background: #fafafa;
}

/* --- 引用块 --- */
blockquote {
    margin: 14pt 0;
    padding: 12pt 18pt;
    border-left: 4pt solid #1a1a1a;
    background: #f7f7f5;
    color: #333;
    font-size: 10.5pt;
    line-height: 1.8;
    page-break-inside: avoid;
}

blockquote p {
    margin: 0 0 8pt 0;
}

blockquote p:last-child {
    margin-bottom: 0;
}

blockquote strong {
    color: #1a1a1a;
}

/* --- 分隔线 --- */
hr {
    border: none;
    border-top: 0.5pt solid #ccc;
    margin: 20pt 0;
}

/* --- 代码 --- */
code {
    font-family: "SF Mono", Menlo, Consolas, monospace;
    background: #f4f4f4;
    padding: 1pt 4pt;
    border-radius: 2pt;
    font-size: 9.5pt;
}

/* --- 报告末尾附注的斜体段（由 * 包裹） --- */
body > p:last-child {
    margin-top: 14pt;
    padding-top: 10pt;
    border-top: 0.5pt dashed #ccc;
    font-size: 9pt;
    color: #777;
    line-height: 1.6;
}

/* 避免孤行 */
p, li {
    orphans: 2;
    widows: 2;
}
"""

# --- 3. 包一层完整 HTML，并把页眉占位符替换成真实的酒店名 ---
full_html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>{HEADER_TEXT}</title>
</head>
<body>
{html_body}
</body>
</html>
"""

css_final = CSS_STR.replace("__HEADER__", HEADER_TEXT)

# --- 4. 生成 PDF ---
HTML(string=full_html).write_pdf(
    target=str(OUT_PATH),
    stylesheets=[CSS(string=css_final)],
)

print(f"OK -> {OUT_PATH} ({OUT_PATH.stat().st_size/1024:.1f} KB)")
